import { useEffect, useRef, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";

import vslVideoAsset from "@/assets/vsl-pag.mp4.asset.json";
import { PurchaseNotifications } from "@/components/xayomi/PurchaseNotifications";
import {
  CHECKOUT_COMPLETE_URL,
  CHECKOUT_URL,
  COMPLETE_PRICE,
  CONTACT_EMAIL,
} from "@/lib/xayomi-config";
import { SOCIAL_PROOF, TESTIMONIALS } from "@/lib/testimonials-data";


export const Route = createFileRoute("/")({
  component: XayomiLanding,
  head: () => ({
    meta: [
      { title: "La Méthode de Mamie Xayomi : Protocole Xayomi 7 Jours" },
      {
        name: "description",
        content:
          "Le Protocole Xayomi : un parcours guidé de 7 jours pour installer une routine de bien-être simple, à votre rythme, depuis chez vous.",
      },
      {
        property: "og:title",
        content: "La Méthode de Mamie Xayomi : Protocole Xayomi 7 Jours",
      },
      {
        property: "og:description",
        content:
          "7 jours, 7 étapes guidées pour prendre soin de votre routine de bien-être. Accès immédiat, 100 % en ligne.",
      },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "/" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "/" }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Product",
          name: "Le Protocole Xayomi : 7 jours",
          brand: { "@type": "Brand", name: "La Méthode de Mamie Xayomi" },
          description:
            "Parcours de bien-être guidé de 7 jours, 100 % en ligne, accessible depuis le téléphone.",
        }),
      },
    ],
  }),
});

/* ---------------------------------------------------------------- UI utils */

function Stars({ count = 5 }: { count?: number }) {
  return (
    <span className="text-gold-deep" aria-label={`Note ${count} sur 5`}>
      {"★".repeat(count)}
      <span className="text-forest/20">{"★".repeat(5 - count)}</span>
    </span>
  );
}

function Leaf({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" aria-hidden="true">
      <path
        d="M20 4c0 9-6.5 14-13 14 0-8 5.5-13 13-14Z"
        stroke="currentColor"
        strokeWidth="1.1"
        strokeLinejoin="round"
      />
      <path d="M18 6C12 9 8 13 6 20" stroke="currentColor" strokeWidth="1.1" />
    </svg>
  );
}

function Cta({
  label,
  href = CHECKOUT_URL,
  className = "",
}: {
  label: string;
  href?: string;
  className?: string;
}) {
  return (
    <a href={href} className={`btn-xayomi ${className}`}>
      {label}
    </a>
  );
}

function SectionTitle({
  eyebrow,
  title,
  subtitle,
  light = false,
}: {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  light?: boolean;
}) {
  return (
    <div className="mx-auto max-w-2xl text-center">
      {eyebrow && <span className="eyebrow">{eyebrow}</span>}
      <h2
        className={`mt-5 text-3xl leading-tight sm:text-4xl md:text-5xl ${
          light ? "text-cream" : "text-forest-deep"
        }`}
      >
        {title}
      </h2>
      {subtitle && (
        <p
          className={`mx-auto mt-4 max-w-xl text-base leading-relaxed sm:text-lg ${
            light ? "text-cream/75" : "text-forest/70"
          }`}
        >
          {subtitle}
        </p>
      )}
    </div>
  );
}

/* ------------------------------------------------------ VSL player */

function VslPlayer() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [muted, setMuted] = useState(true);
  const [showControls, setShowControls] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  useEffect(() => {
    const handleChange = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", handleChange);
    return () => document.removeEventListener("fullscreenchange", handleChange);
  }, []);


  const toggleMute = () => {
    const video = videoRef.current;
    if (!video) return;
    video.muted = !video.muted;
    setMuted(video.muted);
  };

  const toggleFullscreen = async () => {
    const container = containerRef.current;
    if (!container) return;
    try {
      if (!document.fullscreenElement) {
        await container.requestFullscreen();
      } else {
        await document.exitFullscreen();
      }
    } catch {
      // ignore unsupported fullscreen
    }
  };

  const handleContainerClick = () => {
    setShowControls((prev) => !prev);
  };

  return (
    <div
      ref={containerRef}
      className="group relative overflow-hidden rounded-[2rem] border-2 border-gold/30 bg-forest-deep shadow-elegant"
    >
      <div
        className="relative aspect-video overflow-hidden"
        onClick={handleContainerClick}
      >
        <video
          ref={videoRef}
          src={vslVideoAsset.url}
          className="absolute inset-0 h-full w-full object-cover"
          style={{ transform: "scale(1.12)" }}
          width="100%"
          height="100%"
          autoPlay
          muted
          playsInline
          loop
          disablePictureInPicture
          controlsList="nodownload noremoteplayback"
          tabIndex={-1}
          onContextMenu={(e) => e.preventDefault()}
        />
      </div>

      <button
        type="button"
        onClick={toggleFullscreen}
        className={`absolute bottom-3 left-3 z-10 flex h-8 w-8 items-center justify-center rounded-full bg-forest-deep/80 text-cream backdrop-blur transition hover:bg-forest-deep ${
          showControls ? "opacity-100" : "pointer-events-none opacity-0"
        }`}
        aria-label={isFullscreen ? "Quitter le plein écran" : "Plein écran"}
      >
        {isFullscreen ? (
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M8 3v3a2 2 0 0 1-2 2H3" />
            <path d="M21 8h-3a2 2 0 0 1-2-2V3" />
            <path d="M3 16h3a2 2 0 0 1 2 2v3" />
            <path d="M16 21v-3a2 2 0 0 1 2-2h3" />
          </svg>
        ) : (
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M3 8V5a2 2 0 0 1 2-2h3" />
            <path d="M21 8V5a2 2 0 0 0-2-2h-3" />
            <path d="M21 16v3a2 2 0 0 1-2 2h-3" />
            <path d="M3 16v3a2 2 0 0 0 2 2h3" />
          </svg>
        )}
      </button>

      <button
        type="button"
        onClick={toggleMute}
        className={`absolute bottom-3 right-3 z-10 flex h-8 w-8 items-center justify-center rounded-full bg-forest-deep/80 text-cream backdrop-blur transition hover:bg-forest-deep ${
          showControls ? "opacity-100" : "pointer-events-none opacity-0"
        }`}
        aria-label={muted ? "Activer le son" : "Couper le son"}
      >
        {muted ? (
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M11 5 6 9H2v6h4l5 4V5Z" />
            <line x1="23" y1="9" x2="17" y2="15" />
            <line x1="17" y1="9" x2="23" y2="15" />
          </svg>
        ) : (
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
            <path d="M15.54 8.46a5 5 0 0 1 0 7.07" />
            <path d="M19.07 4.93a10 10 0 0 1 0 14.14" />
          </svg>
        )}
      </button>
    </div>
  );
}

/* ------------------------------------------------------ Social proof badge */

function SocialProof() {
  return (
    <div className="flex flex-col items-center justify-center gap-3 text-center sm:flex-row sm:gap-4">
      <div className="flex -space-x-3">
        {SOCIAL_PROOF.avatars.map((avatar, index) => (
          <img
            key={index}
            src={avatar.url}
            alt={`Portrait client ${index + 1}`}
            width={40}
            height={40}
            loading="lazy"
            className="h-10 w-10 rounded-full border-2 border-cream object-cover"
          />
        ))}
      </div>
      <div className="text-forest-deep">
        <p className="font-display text-xl leading-none text-gold-deep">
          {SOCIAL_PROOF.countLabel}
        </p>
        <p className="mt-1 text-xs font-medium tracking-wide text-forest/70">
          {SOCIAL_PROOF.label}
        </p>
      </div>
    </div>
  );
}

/* ---------------------------------------------------- Testimonials section */

function TestimonialCard({
  name,
  location,
  text,
  image,
}: {
  name: string;
  location: string;
  text: string;
  image: { url: string };
}) {
  return (
    <article className="flex w-[280px] shrink-0 flex-col rounded-2xl border border-gold/20 bg-cream p-5 shadow-soft sm:w-[340px]">
      <div className="flex items-center gap-3">
        <img
          src={image.url}
          alt={`Photo de ${name}`}
          width={48}
          height={48}
          loading="lazy"
          className="h-12 w-12 rounded-full border-2 border-gold/30 object-cover"
        />
        <div>
          <p className="font-display text-base text-forest-deep">{name}</p>
          <p className="text-xs text-forest/60">{location}</p>
        </div>
      </div>
      <div className="mt-2">
        <Stars />
      </div>
      <blockquote className="mt-3 flex-1 text-sm leading-relaxed text-forest/80">
        &ldquo;{text}&rdquo;
      </blockquote>
    </article>
  );
}

function TestimonialsSection() {
  return (
    <section className="bg-cream section-pad pt-0">
      <div className="mx-auto max-w-6xl px-5">
        <SectionTitle
          eyebrow="Avis"
          title="Ce que nos clientes disent"
          subtitle="Retrouvez ici quelques retours de celles qui ont découvert l'univers de Mamie Xayomi."
        />
        <div className="relative mt-10 overflow-hidden">
          <div className="flex w-max gap-5 animate-[xay-marquee_50s_linear_infinite] hover:[animation-play-state:paused]">
            {[...TESTIMONIALS, ...TESTIMONIALS].map((t, index) => (
              <TestimonialCard key={`${t.id}-${index}`} {...t} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------- 7-day guarantee */

function GuaranteeSection() {
  return (
    <section className="bg-sand/30 section-pad">
      <div className="mx-auto max-w-3xl px-5 text-center">
        <div className="guarantee-seal mx-auto">
          <span className="text-2xl" aria-hidden="true">
            🛡️
          </span>
          <span className="mt-1 text-[0.6rem] font-semibold uppercase tracking-[0.18em] text-forest-deep/80">
            Garantie
          </span>
          <span className="font-display text-2xl font-bold leading-none text-forest-deep">
            7 JOURS
          </span>
          <span className="mt-1 max-w-[80%] text-[0.55rem] font-semibold uppercase leading-tight tracking-wide text-forest-deep/80">
            Satisfait ou remboursé
          </span>
        </div>

        <h2 className="mt-8 font-display text-2xl leading-tight text-forest-deep sm:text-3xl">
          🛡️ GARANTIE DE 7 JOURS OU VOTRE ARGENT REMBOURSÉ
        </h2>

        <div className="mt-6 rounded-2xl border border-gold/20 bg-cream p-6 text-left shadow-soft sm:p-8">
          <p className="text-sm leading-relaxed text-forest/80 sm:text-base">
            « Découvrez le contenu de Mamie Xayomi sans aucun risque pendant 7 jours.
          </p>
          <p className="mt-3 text-sm leading-relaxed text-forest/80 sm:text-base">
            Vous disposez de 7 jours pour découvrir le contenu et commencer votre parcours. Si vous
            estimez que cette collection ne vous convient pas, vous pouvez demander un
            remboursement dans les 7 jours suivant votre achat.
          </p>
          <p className="mt-3 text-sm leading-relaxed text-forest/80 sm:text-base">
            Votre satisfaction est notre priorité. Vous avez donc 7 jours pour essayer le contenu en
            toute tranquillité.
          </p>
        </div>

        <p className="mt-6 font-display text-lg font-semibold text-gold-deep sm:text-xl">
          « 7 jours pour essayer. Aucun risque. Votre argent est garanti. »
        </p>
      </div>
    </section>
  );
}

/* ---------------------------------------------------------------- FAQ */

function FaqSection() {
  const faqs = [
    {
      q: "Comment vais-je recevoir le contenu ?",
      a: "Vous recevrez votre accès immédiatement après la confirmation du paiement, directement par e-mail. Vous aurez également accès à votre espace membre, où vous pourrez retrouver et consulter tout le contenu acheté.",
    },
    {
      q: "Puis-je accéder au contenu depuis mon téléphone ?",
      a: "Oui. Tout le contenu est numérique et peut être consulté depuis votre téléphone, tablette ou ordinateur, à tout moment.",
    },
    {
      q: "Pendant combien de temps aurai-je accès au contenu ?",
      a: "Votre accès est valable à vie. Après votre achat, vous pourrez consulter le contenu quand vous le souhaitez depuis votre espace membre.",
    },
    {
      q: "Où puis-je acheter les ingrédients ?",
      a: "Tous les ingrédients sont disponibles dans les supermarchés, les marchés locaux ou les magasins de produits naturels. Le carnet comprend également un guide pratique et complet des achats pour vous faciliter la préparation.",
    },
    {
      q: "À quelle vitesse puis-je constater des changements ?",
      a: "Chaque personne est différente et les résultats peuvent varier. Certaines personnes peuvent ressentir des changements dans leur routine et leur bien-être dès les premiers jours, tandis que d'autres peuvent avoir besoin de plus de temps. L'essentiel est de suivre les recommandations et de maintenir une routine régulière.",
    },
    {
      q: "Le paiement est-il sécurisé ?",
      a: "Oui. Le paiement est effectué via une plateforme de paiement sécurisée et vos données sont protégées pendant tout le processus d'achat.",
    },
  ];

  return (
    <section className="bg-cream section-pad">
      <div className="mx-auto max-w-3xl px-5">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl leading-tight text-forest-deep sm:text-4xl">
            ❓ Questions fréquentes
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-base leading-relaxed text-forest/70">
            Tout ce que vous devez savoir avant de commencer votre parcours.
          </p>
        </div>

        <div className="mt-8 space-y-3 sm:mt-10">
          {faqs.map((faq, index) => (
            <details
              key={index}
              className="group rounded-2xl border border-gold/20 bg-cream shadow-soft open:border-gold/40 open:bg-sand/30"
            >
              <summary className="flex cursor-pointer list-none items-center justify-between gap-4 p-4 font-display text-base font-semibold text-forest-deep sm:p-5 sm:text-lg">
                <span>{faq.q}</span>
                <span
                  className="ml-2 shrink-0 text-gold-deep transition-transform duration-300 group-open:rotate-180"
                  aria-hidden="true"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="20"
                    height="20"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="m6 9 6 6 6-6" />
                  </svg>
                </span>
              </summary>
              <div className="px-4 pb-4 pt-0 text-sm leading-relaxed text-forest/80 sm:px-5 sm:pb-5 sm:text-base">
                {faq.a}
              </div>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}

/* -------------------------------------------------------------------- Page */

function XayomiLanding() {
  return (
    <div className="min-h-screen bg-cream pb-24 sm:pb-0">
      {/* ------------------------------------------------------- HEADLINE */}
      <div className="relative overflow-hidden bg-forest-deep">
        <div
          className="pointer-events-none absolute inset-0 opacity-70"
          style={{
            background:
              "radial-gradient(120% 90% at 80% 0%, color-mix(in oklab, var(--gold) 22%, transparent), transparent 60%)",
          }}
          aria-hidden="true"
        />
        <div className="relative bg-gold/10 px-4 py-2 text-center md:py-2.5">
          <p className="text-sm font-medium uppercase tracking-wide text-gold sm:text-base">
            ▶ Regardez cette vidéo complète tant qu’elle est encore disponible.
          </p>
        </div>
      </div>


      {/* --------------------------------------------------------- MINI VSL */}
      <section className="bg-cream section-pad pb-0">
        <div className="mx-auto max-w-5xl px-5">
          <VslPlayer />
        </div>
      </section>

      {/* -------------------------------------------- SOCIAL PROOF (SOUS VSL) */}
      <section className="bg-cream section-pad pb-0 pt-6">
        <div className="mx-auto max-w-5xl px-5">
          <SocialProof />
        </div>
      </section>

      {/* ---------------------------------------------------- AVIS CLIENTES */}
      <TestimonialsSection />

      {/* ---------------------------------------------------------- OFFRE */}
      <section id="offre" className="bg-forest-deep section-pad">
        <div className="mx-auto max-w-6xl px-5">
          <SectionTitle
            light
            title="CHOISISSEZ VOTRE FORMULE"
            subtitle="Découvrez les secrets de Mamie Xayomi et choisissez la formule qui vous correspond le mieux."
          />

          <div className="mt-12 flex justify-center">
            {/* Formule Complète */}
            <div id="formule-complete" className="relative flex w-full max-w-xl flex-col rounded-[2.25rem] border-2 border-gold bg-cream p-6 shadow-gold sm:p-7">
              <div className="absolute -top-4 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-full border border-gold bg-gradient-to-r from-gold to-gold-deep px-4 py-1.5 text-xs font-semibold tracking-wide text-forest-deep shadow-gold">
                ⭐ LE PLUS CHOISI
              </div>

              <div className="text-center">
                <h3 className="text-xl tracking-wide text-forest-deep sm:text-2xl">
                  <span className="font-sans">👑</span> FORMULE COMPLÈTE
                </h3>
                <p className="font-display text-5xl text-forest-deep sm:text-6xl">
                  {COMPLETE_PRICE}
                </p>
                <p className="mt-1 text-xs tracking-[0.12em] text-gold-deep">
                  LA COLLECTION COMPLÈTE DE MAMIE XAYOMI
                </p>
                <p className="mt-1 text-xs font-medium text-gold-deep">LA PLUS CHOISIE PAR NOS CLIENTES</p>
              </div>

              <p className="mt-3 text-center text-sm leading-relaxed text-forest/80">
                48 recettes + 7 guides spécialisés pour différents objectifs de bien-être.
              </p>

              <div className="mt-4 rounded-2xl border border-gold/20 bg-sand/50 p-4">
                <p className="mb-2 text-center text-xs font-semibold tracking-wide text-forest-deep">
                  LES 7 GUIDES INCLUS :
                </p>
                <ul className="grid gap-1.5 text-xs text-forest-deep sm:grid-cols-2">
                  {[
                    "Perte de poids & habitudes alimentaires",
                    "Confort du dos",
                    "Confort des articulations",
                    "Bien-être du foie",
                    "Respiration & bien-être des poumons",
                    "Cheveux & routine capillaire",
                    "Équilibre alimentaire & sucre",
                    "+ Le carnet des 48 recettes",
                  ].map((item) => (
                    <li key={item} className="flex items-start gap-1.5">
                      <span className="text-gold-deep">✓</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="mt-auto pt-5">
                <a href={CHECKOUT_COMPLETE_URL || CHECKOUT_URL} className="btn-xayomi">
                  ✨ JE CHOISIS LA COLLECTION COMPLÈTE • {COMPLETE_PRICE}
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      <GuaranteeSection />
      <FaqSection />

      {/* --------------------------------------------------------- FOOTER */}
      <footer className="bg-forest-deep px-5 py-12 text-cream/60">
        <div className="mx-auto max-w-4xl text-center">
          <p className="font-display text-2xl text-cream">La Méthode de Mamie Xayomi</p>
          <nav className="mt-6 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm">
            <a className="transition-colors hover:text-gold" href="/mentions-legales">
              Mentions légales
            </a>
            <a className="transition-colors hover:text-gold" href="/confidentialite">
              Politique de confidentialité
            </a>
            <a className="transition-colors hover:text-gold" href="/cgv">
              Conditions générales de vente
            </a>
            <a className="transition-colors hover:text-gold" href={`mailto:${CONTACT_EMAIL}`}>
              Contact
            </a>
          </nav>
          <p className="mx-auto mt-8 max-w-xl text-xs leading-relaxed">
            Ce programme est destiné au bien-être et ne remplace pas un avis, un diagnostic ou un
            traitement médical professionnel.
          </p>
          <p className="mt-4 text-xs">© 2026 La Méthode de Mamie Xayomi. Tous droits réservés.</p>
        </div>
      </footer>

      {/* ------------------------------------------ BARRE FIXE MOBILE + NOTIFS */}
      <div className="fixed inset-x-0 bottom-0 z-50 border-t border-gold/25 bg-forest-deep/95 px-4 py-3 backdrop-blur sm:hidden">
        <button
          type="button"
          onClick={() =>
            document.getElementById("offre")?.scrollIntoView({ behavior: "smooth", block: "start" })
          }
          className="flex w-full items-center justify-center rounded-full bg-gradient-to-r from-gold to-gold-deep px-6 py-4 text-base font-semibold text-forest-deep shadow-gold"
        >
          🌿 DÉCOUVRIR LE PROTOCOLE →
        </button>
      </div>

      <PurchaseNotifications />
    </div>
  );
}
