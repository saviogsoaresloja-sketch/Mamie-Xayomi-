/**
 * =========================================================================
 *  PROVVE SOCIALE ET TÉMOIGNAGES CLIENTS
 *  Données modifiables pour les avis et la preuve sociale de la page.
 * =========================================================================
 */

import avatar01 from "@/assets/testimonials/avatar-01.jpg.asset.json";
import avatar02 from "@/assets/testimonials/avatar-02.jpg.asset.json";
import avatar03 from "@/assets/testimonials/avatar-03.jpg.asset.json";
import avatar04 from "@/assets/testimonials/avatar-04.jpg.asset.json";
import avatar05 from "@/assets/testimonials/avatar-05.jpg.asset.json";
import avatar06 from "@/assets/testimonials/avatar-06.jpg.asset.json";
import avatar07 from "@/assets/testimonials/avatar-07.jpg.asset.json";
import avatar08 from "@/assets/testimonials/avatar-08.jpg.asset.json";
import avatar09 from "@/assets/testimonials/avatar-09.jpg.asset.json";
import avatar10 from "@/assets/testimonials/avatar-10.jpg.asset.json";

export type Testimonial = {
  id: string;
  name: string;
  location: string;
  text: string;
  image: { url: string };
};

/**
 * Configuration de la preuve sociale affichée sous la mini VSL.
 * Remplacer `countLabel` par une donnée réelle et vérifiable avant publication.
 */
export const SOCIAL_PROOF = {
  /** Nombre affiché à côté des portraits (modifiable sans toucher au composant). */
  countLabel: "+20 000",
  /** Suite du message affiché sous le nombre. */
  label: "Personnes ont déjà découvert l'univers de Mamie Xayomi",
  /** Portraits affichés en ronde sous forme de cercles superposés. */
  avatars: [avatar01, avatar02, avatar03, avatar04, avatar05] as { url: string }[],
};

/**
 * Témoignages clients affichés dans la section "Avis".
 * Ce sont des exemples fictifs : remplacer nom, photo, ville et texte
 * par de vrais avis clients avant la mise en ligne.
 */
export const TESTIMONIALS: Testimonial[] = [
  {
    id: "1",
    name: "Marie L.",
    location: "France",
    text: "J’avais beaucoup de douleurs au niveau du dos et j’ai décidé d’essayer la routine enseignée par Mamie Xayomi. J’ai beaucoup apprécié la simplicité de la méthode et j’ai ressenti une amélioration significative de mon bien-être.",
    image: avatar01,
  },
  {
    id: "2",
    name: "Sophie D.",
    location: "France",
    text: "J’ai commencé à suivre la routine enseignée par Mamie Xayomi et à préparer la tisane chaque jour. Après quelques jours, j’ai remarqué un changement positif dans ma routine et je suis très satisfaite de mon expérience.",
    image: avatar02,
  },
  {
    id: "3",
    name: "Claire",
    location: "Bordeaux, France",
    text: "Le contenu est très bien organisé et facile à comprendre. J’aime le fait de pouvoir avancer à mon rythme et revenir aux recettes quand j’en ai besoin.",
    image: avatar03,
  },
  {
    id: "4",
    name: "Isabelle",
    location: "Toulouse, France",
    text: "J’ai été agréablement surprise par la quantité de contenu proposée. Les 48 recettes sont variées et les guides complémentaires sont très intéressants.",
    image: avatar04,
  },
  {
    id: "5",
    name: "Nathalie",
    location: "Marseille, France",
    text: "J’aime beaucoup l’univers de Mamie Xayomi. Les recettes sont présentées simplement et donnent envie de prendre davantage soin de sa routine au quotidien.",
    image: avatar05,
  },
  {
    id: "6",
    name: "Élodie",
    location: "Nantes, France",
    text: "Très pratique à utiliser ! Je peux consulter les contenus depuis mon téléphone quand je veux. C’est exactement le format que je recherchais.",
    image: avatar06,
  },
  {
    id: "7",
    name: "Valérie",
    location: "Strasbourg, France",
    text: "J’ai apprécié le côté simple et accessible. Pas besoin de passer des heures à chercher les informations, tout est regroupé au même endroit.",
    image: avatar07,
  },
  {
    id: "8",
    name: "Anne",
    location: "Montpellier, France",
    text: "Les recettes sont devenues la partie que je préfère. J’aime pouvoir découvrir différentes préparations et les intégrer progressivement à ma routine.",
    image: avatar08,
  },
  {
    id: "9",
    name: "Céline",
    location: "Lille, France",
    text: "Une collection vraiment complète. Entre les recettes et les différents guides, il y a beaucoup de choses à découvrir. Je suis contente d’avoir choisi la formule complète.",
    image: avatar09,
  },
  {
    id: "10",
    name: "Françoise",
    location: "Nice, France",
    text: "Une expérience agréable et très facile à suivre. J’ai aimé le format digital et le fait de pouvoir consulter les contenus tranquillement depuis chez moi.",
    image: avatar10,
  },
];
