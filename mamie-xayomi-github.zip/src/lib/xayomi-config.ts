/**
 * =========================================================================
 *  CONFIGURATION CENTRALE : LA MÉTHODE DE MAMIE XAYOMI
 *  Modifiez uniquement ce fichier pour changer prix, lien de paiement,
 *  garantie, avis et notifications d'achat.
 * =========================================================================
 */


/** Prix et URL du checkout : Formule Complète. */
export const COMPLETE_PRICE = "27 €";
export const CHECKOUT_COMPLETE_URL = "https://go.centerpag.com/PPU38CQGLTN";


/** URL du checkout externe. Tous les boutons d'achat pointent ici. */
export const CHECKOUT_URL = "https://go.centerpag.com/PPU38CQGLTN";

/** Intervalle entre deux notifications d'achat, en millisecondes. */
export const PURCHASE_NOTIFICATIONS_INTERVAL = 10000;

export type PurchaseNotification = {
  firstName: string;
  city: string;
  country: string;
};

/**
 * DONNÉES RÉELLES D'ACHAT.
 * Laisser le tableau VIDE tant qu'aucune donnée réelle n'est branchée :
 * le composant reste alors désactivé (ou en mode démonstration explicite).
 */
export const REAL_PURCHASES_DATA: PurchaseNotification[] = [];

/**
 * Mode démonstration des notifications.
 * `false` en production : les données de démonstration sont masquées
 * et aucun badge « DÉMONSTRATION » n'est affiché.
 */
export const PURCHASE_NOTIFICATIONS_DEMO_MODE = false;

/** Exemples de structure : NE PAS publier tels quels comme achats réels. */

export const DEMO_PURCHASES_DATA: PurchaseNotification[] = [
  { firstName: "Marie", city: "Paris", country: "France" },
  { firstName: "Sophie", city: "Lyon", country: "France" },
  { firstName: "Claire", city: "Bordeaux", country: "France" },
  { firstName: "Camille", city: "Nantes", country: "France" },
  { firstName: "Élodie", city: "Lille", country: "France" },
];

/** Coordonnées et mentions du pied de page. */
export const CONTACT_EMAIL = "contact@methode-xayomi.fr";
