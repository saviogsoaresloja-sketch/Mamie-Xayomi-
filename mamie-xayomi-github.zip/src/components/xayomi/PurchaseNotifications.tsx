import { useEffect, useState } from "react";
import {
  DEMO_PURCHASES_DATA,
  PURCHASE_NOTIFICATIONS_DEMO_MODE,
  PURCHASE_NOTIFICATIONS_INTERVAL,
  REAL_PURCHASES_DATA,
  type PurchaseNotification,
} from "@/lib/xayomi-config";

/**
 * Notifications d'achat.
 * - Si `REAL_PURCHASES_DATA` contient des données réelles, elles sont utilisées.
 * - Sinon, les données de démonstration sont affichées sans badge.
 */
export function PurchaseNotifications() {
  const data: PurchaseNotification[] =
    REAL_PURCHASES_DATA.length > 0 ? REAL_PURCHASES_DATA : DEMO_PURCHASES_DATA;

  const [index, setIndex] = useState(0);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (data.length === 0) return;
    let hideId: number;
    const showId = window.setInterval(() => {
      setVisible(true);
      hideId = window.setTimeout(() => {
        setVisible(false);
        setIndex((i) => (i + 1) % data.length);
      }, Math.max(3000, PURCHASE_NOTIFICATIONS_INTERVAL - 2000));
    }, PURCHASE_NOTIFICATIONS_INTERVAL);
    return () => {
      window.clearInterval(showId);
      window.clearTimeout(hideId);
    };
  }, [data.length]);

  const item = data[index];
  if (!item) return null;

  return (
    <div
      aria-live="polite"
      className={`pointer-events-none fixed bottom-24 left-4 z-40 max-w-[17rem] transition-all duration-500 sm:bottom-6 ${
        visible ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-3 opacity-0"
      }`}
    >
      <div className="rounded-2xl border border-gold/25 bg-cream/95 px-4 py-3 shadow-elegant backdrop-blur">
        <p className="text-sm font-medium leading-snug text-forest">
          <span className="text-gold-deep">✓</span> {item.firstName} vient d'accéder au Protocole
          Xayomi
        </p>
        <p className="mt-0.5 text-xs text-forest/60">
          {item.city}, {item.country}
        </p>
      </div>
    </div>
  );
}
